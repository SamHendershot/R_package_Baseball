## ---- include = FALSE, echo = F-----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, echo = F----------------------------------------------------------
library(baseballpackage) 
library(Lahman)
library(dplyr)
library(ggplot2)
data("Batting")
data("Appearances")
data("Salaries")

## -----------------------------------------------------------------------------
get_batter_percs(batter_name = "adamewi01", year_batter = "2021")

## -----------------------------------------------------------------------------
get_all_batter_percs(year = "2021")

## -----------------------------------------------------------------------------
#two players selected
combine_batter_matrix(batter_matrix = c("adamewi01","alcansa01"),"2021")

## -----------------------------------------------------------------------------
MC_batter_runs(batters = c("adamewi01","alcansa01"), year = "2021", trials = 1e4)

## ---- fig.width = 10----------------------------------------------------------
MC_batter_runs_histo()

## -----------------------------------------------------------------------------
teams10 <- subset(Teams, Teams$yearID > 2010, select = yearID:name)

## -----------------------------------------------------------------------------
overallRank(dataset = teams10, x = "SFN", y = "W")

## -----------------------------------------------------------------------------
winsByTeam(dataset = teams10, wins = teams10$W, loses = teams10$L, teams10$name)


## -----------------------------------------------------------------------------
losesByTeam(dataset = teams10, wins = teams10$W, loses = teams10$L, teams10$name)

## -----------------------------------------------------------------------------
rivalry(Teams, "San Francisco Giants", "Oakland A's", "W")

## -----------------------------------------------------------------------------
Salary_2012 <- filterSalaryYear(2011, 2013, 120, 0)
head(Salary_2012)

## -----------------------------------------------------------------------------
SalaryRange <- filterSalaryYear(2011, 2023, 100, 0)
tail(SalaryRange)

## -----------------------------------------------------------------------------
plotSalary(Salary_2012)

## -----------------------------------------------------------------------------
playerSalary("Mookie", "Betts", filterSalaryYear(2012, 2023, 120, 0))

